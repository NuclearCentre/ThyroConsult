const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
const { query } = require('../config/database');
const { generateOTP, hmacHash } = require('../utils/encryption');
const logger = require('../utils/logger');

// ─── Email Transporter ─────────────────────────────────────
const createTransporter = () => nodemailer.createTransporter({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT) || 587,
  secure: process.env.SMTP_SECURE === 'true',
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD },
  tls: { rejectUnauthorized: process.env.NODE_ENV === 'production' },
});

// ─── SMS via Twilio ────────────────────────────────────────
const sendSMS = async (to, message) => {
  if (process.env.NODE_ENV === 'development') {
    logger.info(`[DEV] SMS to ${to}: ${message}`);
    return { success: true, sid: 'DEV_SID' };
  }
  const twilio = require('twilio')(
    process.env.TWILIO_ACCOUNT_SID,
    process.env.TWILIO_AUTH_TOKEN
  );
  const msg = await twilio.messages.create({
    body: message,
    from: process.env.TWILIO_PHONE_NUMBER,
    to,
  });
  return { success: true, sid: msg.sid };
};

// ─── WhatsApp via Twilio ───────────────────────────────────
const sendWhatsApp = async (to, message) => {
  if (process.env.NODE_ENV === 'development') {
    logger.info(`[DEV] WhatsApp to ${to}: ${message}`);
    return { success: true, sid: 'DEV_WA_SID' };
  }
  const twilio = require('twilio')(
    process.env.TWILIO_ACCOUNT_SID,
    process.env.TWILIO_AUTH_TOKEN
  );
  const msg = await twilio.messages.create({
    body: message,
    from: process.env.TWILIO_WHATSAPP_NUMBER,
    to: `whatsapp:${to}`,
  });
  return { success: true, sid: msg.sid };
};

// ─── Email ─────────────────────────────────────────────────
const sendEmail = async ({ to, subject, html, text }) => {
  if (process.env.NODE_ENV === 'development') {
    logger.info(`[DEV] Email to ${to}: ${subject}`);
    return { success: true, messageId: 'DEV_MSG' };
  }
  const transporter = createTransporter();
  const result = await transporter.sendMail({
    from: `"${process.env.EMAIL_FROM_NAME}" <${process.env.EMAIL_FROM_ADDRESS}>`,
    to, subject, html, text,
  });
  return { success: true, messageId: result.messageId };
};

// ─── OTP Core ──────────────────────────────────────────────
/**
 * Generate and store an OTP for a given identifier and purpose
 * Returns the plain OTP (to be sent to user)
 */
const createOTP = async (identifier, purpose, ip = null) => {
  const identifierHash = hmacHash(identifier);
  const otp = generateOTP(parseInt(process.env.OTP_LENGTH) || 6);
  const expiryMinutes = parseInt(process.env.OTP_EXPIRY_MINUTES) || 10;
  const expiresAt = new Date(Date.now() + expiryMinutes * 60 * 1000);

  // Invalidate previous OTPs for this identifier+purpose
  await query(
    `UPDATE otp_verifications
     SET verified = TRUE, verified_at = NOW()
     WHERE identifier = $1 AND purpose = $2 AND verified = FALSE`,
    [identifierHash, purpose]
  );

  // Hash OTP before storing (bcrypt)
  const otpHash = await bcrypt.hash(otp, 10);
  await query(
    `INSERT INTO otp_verifications (identifier, purpose, otp_hash, expires_at, ip_address)
     VALUES ($1, $2, $3, $4, $5)`,
    [identifierHash, purpose, otpHash, expiresAt, ip]
  );

  return otp;
};

/**
 * Verify an OTP
 * Returns { valid: true } or { valid: false, reason: '...' }
 */
const verifyOTP = async (identifier, purpose, submittedOtp) => {
  const identifierHash = hmacHash(identifier);

  const result = await query(
    `SELECT id, otp_hash, expires_at, attempts, max_attempts
     FROM otp_verifications
     WHERE identifier = $1 AND purpose = $2 AND verified = FALSE
     ORDER BY created_at DESC LIMIT 1`,
    [identifierHash, purpose]
  );

  if (!result.rows.length) {
    return { valid: false, reason: 'No active OTP found' };
  }

  const record = result.rows[0];

  if (new Date(record.expires_at) < new Date()) {
    return { valid: false, reason: 'OTP has expired' };
  }

  if (record.attempts >= record.max_attempts) {
    return { valid: false, reason: 'Maximum attempts exceeded' };
  }

  // Increment attempt counter
  await query('UPDATE otp_verifications SET attempts = attempts + 1 WHERE id = $1', [record.id]);

  const isValid = await bcrypt.compare(submittedOtp, record.otp_hash);
  if (!isValid) {
    return { valid: false, reason: 'Incorrect OTP' };
  }

  // Mark as verified
  await query(
    'UPDATE otp_verifications SET verified = TRUE, verified_at = NOW() WHERE id = $1',
    [record.id]
  );

  return { valid: true };
};

// ─── Send OTP via channel ──────────────────────────────────
const sendOTP = async (channel, destination, purpose, ip = null) => {
  const otp = await createOTP(destination, purpose, ip);
  const expiryMinutes = parseInt(process.env.OTP_EXPIRY_MINUTES) || 10;

  const message = `Your ThyroConsult verification code is: ${otp}. Valid for ${expiryMinutes} minutes. Do not share this with anyone.`;

  switch (channel) {
    case 'sms':
      await sendSMS(destination, message);
      break;
    case 'whatsapp':
      await sendWhatsApp(destination, `*ThyroConsult OTP*\n\n${message}`);
      break;
    case 'email':
      await sendEmail({
        to: destination,
        subject: 'ThyroConsult — Email Verification Code',
        html: `
          <div style="font-family:sans-serif;max-width:480px;margin:auto;">
            <h2 style="color:#0F6E56;">ThyroConsult</h2>
            <p>Your email verification code is:</p>
            <div style="font-size:32px;font-weight:bold;letter-spacing:8px;color:#0F6E56;padding:16px;background:#E1F5EE;border-radius:8px;text-align:center;">${otp}</div>
            <p>Valid for ${expiryMinutes} minutes. Do not share this code with anyone.</p>
            <p style="color:#888;font-size:12px;">If you did not request this, please ignore this email.</p>
          </div>`,
        text: message,
      });
      break;
    default:
      throw new Error(`Unknown channel: ${channel}`);
  }

  return { sent: true };
};

// ─── Appointment Reminders ─────────────────────────────────
const sendAppointmentReminder = async (patient, doctor, appointment) => {
  const appointmentTime = new Date(appointment.scheduled_at).toLocaleString('en-IN', {
    timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short'
  });
  const message = `Reminder: Your ThyroConsult appointment with ${doctor.name} is at ${appointmentTime}. A video link will be sent 30 mins before. — ThyroConsult`;

  await Promise.allSettled([
    sendSMS(patient.mobile, message),
    sendWhatsApp(patient.whatsapp || patient.mobile, message),
    sendEmail({
      to: patient.email,
      subject: 'ThyroConsult — Appointment Reminder',
      html: `<div style="font-family:sans-serif;"><h2 style="color:#0F6E56;">Appointment Reminder</h2><p>${message}</p></div>`,
      text: message,
    }),
  ]);
};

module.exports = {
  sendOTP,
  verifyOTP,
  sendSMS,
  sendWhatsApp,
  sendEmail,
  sendAppointmentReminder,
};

require('dotenv').config();
const express = require('express');
const compression = require('compression');
const morgan = require('morgan');
const { testConnection } = require('./config/database');
const logger = require('./utils/logger');
const {
  helmetConfig, corsConfig, generalLimiter, requestId, sanitise,
} = require('./middleware/security');
const routes = require('./routes/index');

const app = express();
const PORT = process.env.PORT || 5000;

// ─── Trust proxy (for correct IP behind reverse proxy) ─────
app.set('trust proxy', 1);

// ─── Core middleware ───────────────────────────────────────
app.use(requestId);
app.use(helmetConfig);
app.use(corsConfig);
app.use(compression());
app.use(express.json({ limit: '10mb' }));          // 10mb for base64 photos
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(sanitise);
app.use(generalLimiter);

// ─── Request logging ───────────────────────────────────────
app.use(morgan('combined', {
  stream: { write: (message) => logger.info(message.trim()) },
  skip: (req) => req.path === '/api/health',       // don't log health checks
}));

// ─── Razorpay webhook — raw body needed for signature check
app.use('/api/payments/webhook', express.raw({ type: 'application/json' }), (req, res, next) => {
  if (Buffer.isBuffer(req.body)) req.body = JSON.parse(req.body.toString());
  next();
});

// ─── API Routes ────────────────────────────────────────────
app.use('/api', routes);

// ─── 404 ───────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found', path: req.path });
});

// ─── Global error handler ──────────────────────────────────
app.use((err, req, res, next) => {
  const status = err.status || 500;
  logger.error('Unhandled error', {
    error: err.message,
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined,
    path: req.path,
    method: req.method,
    requestId: req.requestId,
  });

  // Never expose internal error details in production
  const message = process.env.NODE_ENV === 'production'
    ? 'An internal error occurred'
    : err.message;

  res.status(status).json({ error: message, requestId: req.requestId });
});

// ─── Start server ──────────────────────────────────────────
const startServer = async () => {
  // Verify required environment variables
  const required = ['DB_USER', 'DB_PASSWORD', 'JWT_SECRET', 'JWT_REFRESH_SECRET',
                    'ENCRYPTION_KEY', 'PHI_ENCRYPTION_KEY', 'PHOTO_ENCRYPTION_KEY'];
  const missing = required.filter(key => !process.env[key]);
  if (missing.length > 0) {
    logger.error(`Missing required environment variables: ${missing.join(', ')}`);
    process.exit(1);
  }

  // Test database connection
  const dbConnected = await testConnection();
  if (!dbConnected) {
    logger.error('Cannot connect to database. Exiting.');
    process.exit(1);
  }

  const server = app.listen(PORT, () => {
    logger.info(`ThyroConsult API running on port ${PORT}`, {
      env: process.env.NODE_ENV,
      port: PORT,
    });
  });

  // ─── Graceful shutdown ─────────────────────────────────
  const shutdown = async (signal) => {
    logger.info(`${signal} received — shutting down gracefully`);
    server.close(async () => {
      const { pool } = require('./config/database');
      await pool.end();
      logger.info('Database pool closed. Goodbye.');
      process.exit(0);
    });
    setTimeout(() => {
      logger.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));

  process.on('unhandledRejection', (reason) => {
    logger.error('Unhandled Promise Rejection', { reason: String(reason) });
  });
  process.on('uncaughtException', (err) => {
    logger.error('Uncaught Exception', { error: err.message });
    process.exit(1);
  });
};

startServer();

module.exports = app;

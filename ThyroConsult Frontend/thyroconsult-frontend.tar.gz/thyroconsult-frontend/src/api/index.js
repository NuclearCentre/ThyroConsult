import axios from 'axios';

// ─────────────────────────────────────────────────────────────
// API CONFIGURATION
// To switch to a different API provider or deployment:
//   1. Change REACT_APP_API_URL in your .env file
//   2. That's it. Nothing else needs to change.
// ─────────────────────────────────────────────────────────────
const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

// ─── Request interceptor: attach JWT ─────────────────────────
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('accessToken');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// ─── Response interceptor: auto-refresh on 401 ───────────────
let isRefreshing = false;
let failedQueue = [];

const processQueue = (error, token = null) => {
  failedQueue.forEach(({ resolve, reject }) => {
    if (error) reject(error);
    else resolve(token);
  });
  failedQueue = [];
};

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    if (error.response?.status === 401 && !originalRequest._retry) {
      if (error.response?.data?.code === 'TOKEN_EXPIRED') {
        if (isRefreshing) {
          return new Promise((resolve, reject) => {
            failedQueue.push({ resolve, reject });
          }).then((token) => {
            originalRequest.headers.Authorization = `Bearer ${token}`;
            return api(originalRequest);
          });
        }
        originalRequest._retry = true;
        isRefreshing = true;
        try {
          const refreshToken = localStorage.getItem('refreshToken');
          if (!refreshToken) throw new Error('No refresh token');
          const res = await axios.post(`${BASE_URL}/auth/refresh`, { refreshToken });
          const { accessToken, refreshToken: newRefresh } = res.data;
          localStorage.setItem('accessToken', accessToken);
          localStorage.setItem('refreshToken', newRefresh);
          api.defaults.headers.Authorization = `Bearer ${accessToken}`;
          processQueue(null, accessToken);
          return api(originalRequest);
        } catch (refreshError) {
          processQueue(refreshError, null);
          localStorage.clear();
          window.location.href = '/login';
          return Promise.reject(refreshError);
        } finally {
          isRefreshing = false;
        }
      }
    }
    return Promise.reject(error);
  }
);

// ─────────────────────────────────────────────────────────────
// AUTH ENDPOINTS
// ─────────────────────────────────────────────────────────────
export const authAPI = {
  registerStep1: (data) => api.post('/auth/register/step1', data),
  sendOTP: (patientId, channel) => api.post('/auth/register/send-otp', { patientId, channel }),
  verifyOTP: (patientId, channel, otp) => api.post('/auth/register/verify-otp', { patientId, channel, otp }),
  saveConsent: (data) => api.post('/auth/register/consent', data),
  savePhoto: (patientId, photoBase64) => api.post('/auth/register/photo', { patientId, photoBase64 }),
  selectDoctor: (patientId, doctorId) => api.post('/auth/register/select-doctor', { patientId, doctorId }),
  login: (identifier, password, role) => api.post('/auth/login', { identifier, password, role }),
  refresh: (refreshToken) => api.post('/auth/refresh', { refreshToken }),
  logout: (refreshToken) => api.post('/auth/logout', { refreshToken }),
};

// ─────────────────────────────────────────────────────────────
// PATIENT ENDPOINTS
// ─────────────────────────────────────────────────────────────
export const patientAPI = {
  getProfile: (id) => api.get(`/patients/${id}`),
  updateProfile: (id, data) => api.patch(`/patients/${id}`, data),
  getPhoto: (id) => `${BASE_URL}/patients/${id}/photo`,
  getDocuments: (id, category) => api.get(`/patients/${id}/documents`, { params: { category } }),
  uploadDocument: (id, file, category, onProgress) => {
    const form = new FormData();
    form.append('file', file);
    form.append('category', category);
    return api.post(`/patients/${id}/documents`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (e) => onProgress && onProgress(Math.round((e.loaded * 100) / e.total)),
    });
  },
  downloadDocument: (patientId, docId) => api.get(`/patients/${patientId}/documents/${docId}/download`, { responseType: 'blob' }),
  getBloodValues: (id, params) => api.get(`/patients/${id}/blood-values`, { params }),
  addBloodValue: (id, data) => api.post(`/patients/${id}/blood-values`, data),
  getConsultations: (id) => api.get(`/patients/${id}/consultations`),
  getInvoices: (id) => api.get(`/patients/${id}/invoices`),
  downloadInvoice: (paymentId) => api.get(`/payments/${paymentId}/invoice/download`, { responseType: 'blob' }),
};

// ─────────────────────────────────────────────────────────────
// DOCTOR ENDPOINTS
// ─────────────────────────────────────────────────────────────
export const doctorAPI = {
  list: () => api.get('/doctors'),
  getProfile: (id) => api.get(`/doctors/${id}`),
  getAppointments: (id, date) => api.get(`/doctors/${id}/appointments`, { params: { date } }),
  getPatientView: (doctorId, patientId) => api.get(`/doctors/${doctorId}/patients/${patientId}`),
  saveNotes: (consultationId, data) => api.post(`/consultations/${consultationId}/notes`, data),
};

// ─────────────────────────────────────────────────────────────
// APPOINTMENT & PAYMENT ENDPOINTS
// ─────────────────────────────────────────────────────────────
export const appointmentAPI = {
  book: (data) => api.post('/appointments', data),
  verifyPayment: (data) => api.post('/payments/verify', data),
};

// ─────────────────────────────────────────────────────────────
// ADMIN ENDPOINTS
// ─────────────────────────────────────────────────────────────
export const adminAPI = {
  getStats: () => api.get('/admin/stats'),
  listPatients: (params) => api.get('/admin/patients', { params }),
  listDoctors: () => api.get('/admin/doctors'),
  createDoctor: (data) => api.post('/admin/doctors', data),
  setDoctorStatus: (id, isActive) => api.patch(`/admin/doctors/${id}/status`, { isActive }),
  getAuditLog: (params) => api.get('/admin/audit-log', { params }),
  exportAuditLog: () => api.get('/admin/audit-log/export', { responseType: 'blob' }),
  getPaymentReport: (params) => api.get('/admin/payments/report', { params }),
  getEncryptionStatus: () => api.get('/admin/encryption/status'),
};

export default api;

import React, { useState, useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, ResponsiveContainer } from 'recharts';
import { doctorAPI, patientAPI } from '../../api';
import { DoctorSidebar } from '../../components/common/Sidebar';
import { Badge, StatusBadge, EmptyState, Spinner, SectionHeader, HIPAABadge } from '../../components/common/index';
import { useAuth } from '../../context/AuthContext';

const DoctorLayout = ({ children, doctor }) => (
  <div className="app-shell">
    <DoctorSidebar doctor={doctor} />
    <main className="main-area">
      <div className="page-content">{children}</div>
    </main>
  </div>
);

// ─── Appointment queue + Patient detail (main view) ────────
const DoctorDashboard = ({ doctor }) => {
  const [appointments, setAppointments] = useState([]);
  const [selectedAppt, setSelectedAppt] = useState(null);
  const [patientDetail, setPatientDetail] = useState(null);
  const [patientDocs, setPatientDocs] = useState([]);
  const [consultations, setConsultations] = useState([]);
  const [bloodValues, setBloodValues] = useState([]);
  const [selectedTest, setSelectedTest] = useState('TSH');
  const [notes, setNotes] = useState({ chiefComplaint:'', diagnosis:'', doctorNotes:'', followUpNotes:'' });
  const [notesSaved, setNotesSaved] = useState(false);
  const [loading, setLoading] = useState(false);
  const [paymentInfo, setPaymentInfo] = useState(null);
  const today = new Date().toISOString().split('T')[0];

  useEffect(() => {
    if (!doctor) return;
    doctorAPI.getAppointments(doctor.id, today)
      .then(r => { setAppointments(r.data.appointments || []); })
      .catch(() => {});
  }, [doctor]);

  const selectPatient = async (appt) => {
    setSelectedAppt(appt);
    setLoading(true);
    try {
      const [detail, docs, consults, bv] = await Promise.all([
        doctorAPI.getPatientView(doctor.id, appt.patient.id),
        patientAPI.getDocuments(appt.patient.id),
        patientAPI.getConsultations(appt.patient.id),
        patientAPI.getBloodValues(appt.patient.id, { testName: selectedTest }),
      ]);
      setPatientDetail(detail.data);
      setPatientDocs(docs.data.documents || []);
      setConsultations(consults.data.consultations || []);
      setBloodValues(bv.data.values || []);
      setPaymentInfo(appt.payment);
      setNotesSaved(false);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const loadBloodValues = async (test) => {
    if (!selectedAppt) return;
    setSelectedTest(test);
    const r = await patientAPI.getBloodValues(selectedAppt.patient.id, { testName: test });
    setBloodValues(r.data.values || []);
  };

  const saveNotes = async (consultationId) => {
    if (!consultationId) return;
    await doctorAPI.saveNotes(consultationId, notes);
    setNotesSaved(true);
  };

  const downloadDoc = async (docId, name, patientId) => {
    const res = await patientAPI.downloadDocument(patientId, docId);
    const url = URL.createObjectURL(new Blob([res.data]));
    const a = document.createElement('a'); a.href = url; a.download = name; a.click();
  };

  const TESTS = ['TSH','Free T3','Free T4','Haemoglobin','Vitamin D','Anti-TPO'];

  return (
    <>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
        <h2 style={{ fontSize:'1.4rem' }}>Doctor dashboard</h2>
        <div style={{ display:'flex', gap:10 }}>
          <span className="badge badge-blue">Today: {today}</span>
          <HIPAABadge />
        </div>
      </div>

      {/* Stat row */}
      <div className="stat-grid" style={{ marginBottom:20 }}>
        <div className="stat-card"><div className="stat-label">Today's appointments</div><div className="stat-value">{appointments.length}</div></div>
        <div className="stat-card"><div className="stat-label">Pending review</div><div className="stat-value" style={{ color:'var(--amber-600)' }}>{appointments.filter(a => a.status === 'scheduled').length}</div></div>
        <div className="stat-card"><div className="stat-label">Completed today</div><div className="stat-value" style={{ color:'var(--teal-600)' }}>{appointments.filter(a => a.status === 'completed').length}</div></div>
        <div className="stat-card"><div className="stat-label">Consultation fee</div><div className="stat-value" style={{ fontSize:16, marginTop:4 }}>₹{doctor?.consultationFee?.toLocaleString('en-IN') || '—'}</div></div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'280px 1fr', gap:20 }}>
        {/* Queue */}
        <div className="card" style={{ padding:0, overflow:'hidden' }}>
          <div style={{ padding:'14px 16px', borderBottom:'1px solid var(--border)', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <span style={{ fontWeight:600, fontSize:13 }}>Appointment queue</span>
            <span className="badge badge-blue">{appointments.length}</span>
          </div>
          {appointments.length === 0 ? <EmptyState icon="📅" title="No appointments today" subtitle="" /> : appointments.map(appt => (
            <div key={appt.id} onClick={() => selectPatient(appt)} style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', cursor:'pointer', background: selectedAppt?.id === appt.id ? 'var(--teal-50)' : 'transparent', transition:'background 0.12s' }}>
              <div style={{ display:'flex', gap:10 }}>
                <div style={{ width:36,height:36,borderRadius:'50%',background:'var(--blue-50)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:600,color:'var(--blue-800)',flexShrink:0 }}>
                  {appt.patient.name.split(' ')[0][0]}{appt.patient.name.split(' ')[1]?.[0]}
                </div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:13, fontWeight:500 }}>{appt.patient.name}</div>
                  <div style={{ fontSize:11, color:'var(--text-tertiary)' }}>{appt.patient.code} · {appt.consultationType}</div>
                  <div style={{ marginTop:4, display:'flex', gap:6 }}>
                    <span className={`badge badge-${appt.payment?.status === 'confirmed' ? 'teal' : 'amber'}`} style={{ fontSize:10 }}>
                      {appt.payment?.status === 'confirmed' ? `✓ Paid ₹${appt.payment.amount?.toLocaleString('en-IN')}` : 'Payment pending'}
                    </span>
                  </div>
                </div>
                <div style={{ fontSize:11, color:'var(--text-tertiary)', textAlign:'right' }}>
                  {new Date(appt.scheduledAt).toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' })}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Patient detail */}
        <div>
          {!selectedAppt ? (
            <div className="card" style={{ display:'flex', alignItems:'center', justifyContent:'center', minHeight:300 }}>
              <EmptyState icon="👆" title="Select a patient" subtitle="Click any appointment in the queue to view patient details" />
            </div>
          ) : loading ? (
            <div className="card" style={{ display:'flex', alignItems:'center', justifyContent:'center', minHeight:300 }}><Spinner size={32} /></div>
          ) : (
            <>
              {/* Patient header */}
              <div className="card" style={{ marginBottom:16 }}>
                <div style={{ display:'flex', gap:16, alignItems:'flex-start' }}>
                  {/* Photo */}
                  <div style={{ width:68, height:68, borderRadius:'50%', background:'var(--teal-50)', border:'2px solid var(--teal-200)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, overflow:'hidden' }}>
                    <img src={`${process.env.REACT_APP_API_URL}/patients/${selectedAppt.patient.id}/photo`} alt="Patient" style={{ width:'100%', height:'100%', objectFit:'cover' }} onError={e => { e.target.style.display='none'; }} />
                    <span style={{ fontSize:24, color:'var(--teal-400)' }}>👤</span>
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:16, fontWeight:600 }}>{patientDetail?.firstName} {patientDetail?.middleName || ''} {patientDetail?.lastName}</div>
                    <div style={{ fontSize:12, color:'var(--text-tertiary)', marginBottom:10 }}>{selectedAppt.patient.code} · {selectedAppt.consultationType} consultation</div>
                    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8 }}>
                      {[['Age / DOB', patientDetail?.dob || '—'],['Gender', patientDetail?.gender || '—'],['Blood group', patientDetail?.bloodGroup || '—'],['Mobile', patientDetail?.mobile || '—'],['Email', patientDetail?.email || '—'],['Payment', paymentInfo?.status === 'confirmed' ? `✓ ₹${paymentInfo?.amount?.toLocaleString('en-IN')} paid` : 'Pending']].map(([label, val]) => (
                        <div key={label} style={{ fontSize:12 }}>
                          <div style={{ color:'var(--text-tertiary)', marginBottom:1 }}>{label}</div>
                          <div style={{ fontWeight:500, color: label === 'Payment' && paymentInfo?.status === 'confirmed' ? 'var(--teal-600)' : 'var(--text-primary)' }}>{val}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
                    <button className="btn btn-primary btn-sm">📹 Start consultation</button>
                    <button className="btn btn-secondary btn-sm" onClick={() => saveNotes(consultations[0]?.id)}>📝 Save notes</button>
                    <button className="btn btn-secondary btn-sm">💊 Send prescription</button>
                  </div>
                </div>
              </div>

              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:16 }}>
                {/* Documents */}
                <div className="card">
                  <div className="card-title">Uploaded documents</div>
                  {patientDocs.length === 0 ? <EmptyState icon="📁" title="No documents uploaded" subtitle="" /> : patientDocs.slice(0,5).map(doc => (
                    <div key={doc.id} style={{ display:'flex', alignItems:'center', gap:8, padding:'7px 0', borderBottom:'1px solid var(--border)', fontSize:12 }}>
                      <span>📄</span>
                      <div style={{ flex:1 }}>
                        <div style={{ fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', maxWidth:140 }}>{doc.originalName}</div>
                        <div style={{ fontSize:10, color:'var(--text-tertiary)' }}>{doc.category} · {(doc.file_size_bytes/1024).toFixed(0)} KB</div>
                      </div>
                      <button className="btn btn-ghost btn-sm" onClick={() => downloadDoc(doc.id, doc.originalName, selectedAppt.patient.id)} style={{ padding:'3px 7px', fontSize:11 }}>⬇</button>
                    </div>
                  ))}
                </div>

                {/* Payment */}
                <div className="card">
                  <div className="card-title">Payment details</div>
                  {paymentInfo && (
                    <>
                      {[['Consultation fee','₹1,200'],['Platform fee','₹50'],['GST (18%)','₹225'],['Total paid',`₹${paymentInfo.amount?.toLocaleString('en-IN') || '—'}`]].map(([label, val]) => (
                        <div key={label} style={{ display:'flex', justifyContent:'space-between', fontSize:13, padding:'5px 0', borderBottom:'1px solid var(--border)' }}>
                          <span style={{ color:'var(--text-secondary)' }}>{label}</span>
                          <span style={{ fontWeight: label.includes('Total') ? 600 : 400 }}>{val}</span>
                        </div>
                      ))}
                      <div style={{ marginTop:10 }}>
                        <span className={`badge badge-${paymentInfo.status === 'confirmed' ? 'teal' : 'amber'}`}>{paymentInfo.status === 'confirmed' ? '✓ Razorpay confirmed' : 'Pending'}</span>
                        {paymentInfo.transactionId && <div style={{ fontSize:10, color:'var(--text-tertiary)', marginTop:4 }}>Txn: {paymentInfo.transactionId}</div>}
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* Blood report trends */}
              <div className="card" style={{ marginBottom:16 }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
                  <div className="card-title" style={{ marginBottom:0 }}>Blood report trends</div>
                </div>
                <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:12 }}>
                  {TESTS.map(t => (
                    <button key={t} onClick={() => loadBloodValues(t)} style={{ padding:'3px 12px', borderRadius:20, border:`1px solid ${selectedTest === t ? 'var(--blue-400)' : 'var(--border-md)'}`, background: selectedTest === t ? 'var(--blue-50)' : 'transparent', color: selectedTest === t ? 'var(--blue-800)' : 'var(--text-secondary)', fontSize:11, cursor:'pointer' }}>
                      {t}
                    </button>
                  ))}
                </div>
                {bloodValues.length < 2
                  ? <EmptyState icon="📊" title={`No ${selectedTest} data`} subtitle="Patient has not uploaded reports containing this value" />
                  : (
                    <ResponsiveContainer width="100%" height={180}>
                      <LineChart data={bloodValues.map(v => ({ date: new Date(v.report_date).toLocaleDateString('en-IN', { month:'short', year:'2-digit' }), value: parseFloat(v.value), abnormal: v.is_abnormal }))}>
                        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                        <XAxis dataKey="date" tick={{ fontSize:9 }} />
                        <YAxis tick={{ fontSize:9 }} domain={['auto','auto']} />
                        <Tooltip formatter={(v) => [`${v}`, selectedTest]} contentStyle={{ fontSize:11 }} />
                        {bloodValues[0]?.reference_high && <ReferenceLine y={bloodValues[0].reference_high} stroke="var(--red-200)" strokeDasharray="4 3" />}
                        <Line type="monotone" dataKey="value" stroke="var(--blue-400)" strokeWidth={2}
                          dot={(props) => { const { cx, cy, payload } = props; return <circle key={cx} cx={cx} cy={cy} r={4} fill={payload.abnormal ? 'var(--red-400)' : 'var(--blue-400)'} stroke="#fff" strokeWidth={1.5} />; }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  )
                }
              </div>

              {/* Consultation notes */}
              <div className="card">
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
                  <div className="card-title" style={{ marginBottom:0 }}>Consultation notes</div>
                  {notesSaved && <span style={{ fontSize:12, color:'var(--teal-600)' }}>✓ Saved</span>}
                </div>
                {[['chiefComplaint','Chief complaint'],['diagnosis','Diagnosis'],['doctorNotes','Clinical notes & observations'],['followUpNotes','Follow-up instructions']].map(([key, label]) => (
                  <div className="form-group" key={key}>
                    <label className="form-label">{label}</label>
                    <textarea className="form-input" rows={key === 'doctorNotes' ? 3 : 2} value={notes[key]} onChange={e => setNotes(p => ({ ...p, [key]: e.target.value }))} placeholder={`Enter ${label.toLowerCase()}...`} style={{ resize:'vertical' }} />
                  </div>
                ))}
                {consultations.length > 0 && consultations[0].doctorNotes && (
                  <div style={{ background:'var(--gray-50)', borderRadius:'var(--radius-md)', padding:12, marginBottom:14 }}>
                    <div style={{ fontSize:12, fontWeight:500, marginBottom:4 }}>Previous notes — {consultations[0].completedAt ? new Date(consultations[0].completedAt).toLocaleDateString('en-IN') : '—'}</div>
                    <div style={{ fontSize:12, color:'var(--text-secondary)', lineHeight:1.6 }}>{consultations[0].doctorNotes}</div>
                  </div>
                )}
                <button className="btn btn-primary" onClick={() => saveNotes(consultations[0]?.id)}>💾 Save notes</button>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
};

// ─── Doctor portal ─────────────────────────────────────────
const DoctorPortal = () => {
  const { user } = useAuth();
  const [doctor, setDoctor] = useState(null);

  useEffect(() => {
    if (user?.id) doctorAPI.getProfile(user.id).then(r => setDoctor(r.data)).catch(() => {});
  }, [user]);

  return (
    <DoctorLayout doctor={doctor}>
      <Routes>
        <Route path="dashboard" element={<DoctorDashboard doctor={doctor} />} />
        <Route path="appointments" element={<DoctorDashboard doctor={doctor} />} />
        <Route path="*" element={<DoctorDashboard doctor={doctor} />} />
      </Routes>
    </DoctorLayout>
  );
};

export default DoctorPortal;

import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LoadingScreen } from './components/common/index';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/patient/RegisterPage';
import PatientPortal from './pages/patient/PatientPortal';
import DoctorPortal from './pages/doctor/DoctorPortal';
import AdminPortal from './pages/admin/AdminPortal';
import './styles/global.css';

// ─── Protected route ───────────────────────────────────────
const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, loading } = useAuth();
  if (loading) return <LoadingScreen message="Authenticating..." />;
  if (!user) return <Navigate to="/login" replace />;
  if (allowedRoles && !allowedRoles.includes(user.role)) return <Navigate to="/login" replace />;
  return children;
};

// ─── Root redirect ─────────────────────────────────────────
const RootRedirect = () => {
  const { user, loading } = useAuth();
  if (loading) return <LoadingScreen />;
  if (!user) return <Navigate to="/login" replace />;
  if (user.role === 'patient') return <Navigate to="/patient/dashboard" replace />;
  if (user.role === 'doctor') return <Navigate to="/doctor/dashboard" replace />;
  return <Navigate to="/admin/dashboard" replace />;
};

const App = () => (
  <AuthProvider>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<RootRedirect />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />

        {/* Patient portal */}
        <Route path="/patient/*" element={
          <ProtectedRoute allowedRoles={['patient']}>
            <PatientPortal />
          </ProtectedRoute>
        } />

        {/* Doctor portal */}
        <Route path="/doctor/*" element={
          <ProtectedRoute allowedRoles={['doctor']}>
            <DoctorPortal />
          </ProtectedRoute>
        } />

        {/* Admin portal */}
        <Route path="/admin/*" element={
          <ProtectedRoute allowedRoles={['admin', 'super_admin']}>
            <AdminPortal />
          </ProtectedRoute>
        } />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
    <ToastContainer position="bottom-right" autoClose={4000} hideProgressBar newestOnTop theme="light" />
  </AuthProvider>
);

export default App;
